var searchData=
[
  ['collatz_2ec_2b_2b',['Collatz.c++',['../Collatz_8c_09_09.html',1,'']]],
  ['collatz_2eh',['Collatz.h',['../Collatz_8h.html',1,'']]]
];
