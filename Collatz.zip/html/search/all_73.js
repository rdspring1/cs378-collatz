var searchData=
[
  ['spherecollatz_2ec_2b_2b',['SphereCollatz.c++',['../SphereCollatz_8c_09_09.html',1,'']]],
  ['spherecollatz_5fnaive_2ec_2b_2b',['SphereCollatz_Naive.c++',['../SphereCollatz__Naive_8c_09_09.html',1,'']]]
];
