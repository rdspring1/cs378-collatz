var searchData=
[
  ['init_5fcache',['init_cache',['../Collatz_8c_09_09.html#a712542e20fd4c25bc655d5f0c2b9a5e1',1,'init_cache(int cache[], int size):&#160;Collatz.c++'],['../Collatz_8h.html#a959552789d3d9809f9ace24dde295f3f',1,'init_cache(int[], int):&#160;Collatz.c++'],['../SphereCollatz_8c_09_09.html#a712542e20fd4c25bc655d5f0c2b9a5e1',1,'init_cache(int cache[], int size):&#160;SphereCollatz.c++']]]
];
