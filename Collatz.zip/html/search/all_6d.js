var searchData=
[
  ['main',['main',['../RunCollatz_8c_09_09.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;RunCollatz.c++'],['../SphereCollatz_8c_09_09.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;SphereCollatz.c++'],['../SphereCollatz__Naive_8c_09_09.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;SphereCollatz_Naive.c++'],['../TestCollatz_8c_09_09.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;TestCollatz.c++'],['../TestGenerator_8c_09_09.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;TestGenerator.c++']]]
];
